<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>API_KEY</key>
	<string>AIzaSyBZ9FnqlhJFPXfLqEbUTx-dHF1Y4WcMDSA</string>
	<key>GCM_SENDER_ID</key>
	<string>734067921066</string>
	<key>PLIST_VERSION</key>
	<string>1</string>
	<key>BUNDLE_ID</key>
	<string>Fortress.org</string>
	<key>PROJECT_ID</key>
	<string>fortress-7a7ec</string>
	<key>STORAGE_BUCKET</key>
	<string>fortress-7a7ec.firebasestorage.app</string>
	<key>IS_ADS_ENABLED</key>
	<false></false>
	<key>IS_ANALYTICS_ENABLED</key>
	<false></false>
	<key>IS_APPINVITE_ENABLED</key>
	<true></true>
	<key>IS_GCM_ENABLED</key>
	<true></true>
	<key>IS_SIGNIN_ENABLED</key>
	<true></true>
	<key>GOOGLE_APP_ID</key>
	<string>1:734067921066:ios:396ead8a94105588c280d3</string>
</dict>
</plist>
