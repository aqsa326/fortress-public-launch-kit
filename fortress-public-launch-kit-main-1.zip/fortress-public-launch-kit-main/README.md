# Fortress Admin Portal

## Deploy Instructions

1. Run `firebase init hosting functions`
2. Paste config into `firebase.json`
3. Deploy: `firebase deploy`

## Features

- Firebase Admin SDK
- Google Sign-In
- Analytics logging

http:///mnt/data/fortress_deploy_kit.zip
Core files (index.html, styles.css, analytics.js)
	•	Firebase deploy config (firebase.json)
	•	Privacy policy
	•	GitHub CI workflow
	•	README with setup instructions